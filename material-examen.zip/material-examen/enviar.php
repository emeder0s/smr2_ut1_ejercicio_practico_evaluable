<?php
// Este archivo NO hay que tocarlo: recibe los datos del formulario de contacto.
$nombre     = htmlspecialchars($_REQUEST['nombre']     ?? '');
$email      = htmlspecialchars($_REQUEST['email']      ?? '');
$plataforma = htmlspecialchars($_REQUEST['plataforma'] ?? '');
$mensaje    = htmlspecialchars($_REQUEST['mensaje']    ?? '');
$metodo     = $_SERVER['REQUEST_METHOD'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mensaje recibido | Nivel Extra</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>¡Mensaje recibido!</h1>
    <ul>
        <li>Nombre: <strong><?= $nombre ?></strong></li>
        <li>Correo: <strong><?= $email ?></strong></li>
        <li>Plataforma: <strong><?= $plataforma ?></strong></li>
        <li>Mensaje: <strong><?= $mensaje ?></strong></li>
        <li>Método: <strong><?= $metodo ?></strong></li>
    </ul>
    <?php if ($nombre === '' || $mensaje === ''): ?>
        <p>Atención: algún dato ha llegado vacío. Revisen los <code>name</code> de su formulario.</p>
    <?php endif; ?>
    <p><a href="index.html">Volver al inicio</a></p>
</body>
</html>
