#!/bin/bash
# Recoge la prueba práctica para entregarla en Moodle.
# Ejecútenlo así:   sudo bash recoge.sh
# No modifiquen este archivo.

DIR=/var/www/html/examen
USUARIO="${SUDO_USER:-$USER}"
CASA=$(getent passwd "$USUARIO" | cut -d: -f6)
[ -z "$CASA" ] && CASA="$HOME"
EQUIPO=$(hostname)
SALIDA="$CASA/examen-$USUARIO.tar.gz"

if [ "$(id -u)" -ne 0 ]; then
  echo "ERROR: ejecútenlo con sudo:  sudo bash recoge.sh"
  exit 1
fi
if [ ! -d "$DIR" ]; then
  echo "ERROR: no existe la carpeta $DIR"
  exit 1
fi

TMP=$(mktemp -d)
E="$TMP/entrega"
mkdir -p "$E/web"

# 1. Sus archivos (sin carpetas ocultas ni archivos de más de 5 MB)
find "$DIR" -maxdepth 3 -type f -size -5M ! -path '*/.*' | while read -r f; do
  rel="${f#$DIR/}"
  mkdir -p "$E/web/$(dirname "$rel")"
  cp -p "$f" "$E/web/$rel"
done

# 2. Datos del equipo
{
  echo "usuario=$USUARIO"
  echo "equipo=$EQUIPO"
  echo "fecha=$(date '+%Y-%m-%d %H:%M:%S')"
} > "$E/info.txt"

# 3. Permisos de la carpeta
ls -la "$DIR" > "$E/permisos.txt" 2>&1

# 4. Estado de Apache
if systemctl is-active --quiet apache2 2>/dev/null || pgrep -x apache2 >/dev/null; then
  echo "activo" > "$E/apache.txt"
else
  echo "parado" > "$E/apache.txt"
fi

# 5. Peticiones al examen en el registro de accesos
cat /var/log/apache2/access.log.1 /var/log/apache2/access.log 2>/dev/null | grep ' /examen' | tail -n 2000 > "$E/accesos.txt"

# 6. Qué responde el servidor
python3 - "$E" <<'PY'
import sys, urllib.request, urllib.parse, urllib.error
dest = sys.argv[1]
UA = {"User-Agent": "Recoge-Examen/1.0"}
def pide(ruta, datos=None):
    try:
        req = urllib.request.Request("http://localhost" + ruta, data=datos, headers=UA)
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, b""
    except Exception as e:
        return 0, str(e).encode()
with open(dest + "/http.txt", "w") as f:
    for ruta in ["/examen/", "/examen/index.html", "/examen/contacto.html", "/examen/estilos.css", "/examen/logo.png", "/examen/privado.html"]:
        f.write("%s %s\n" % (ruta, pide(ruta)[0]))
datos = urllib.parse.urlencode({"nombre": "Corrector", "email": "corrector@ejemplo.es",
                                "plataforma": "PC", "mensaje": "ComprobacionDelCorrector"}).encode()
cod, cuerpo = pide("/examen/enviar.php", datos)
with open(dest + "/php.txt", "wb") as f:
    f.write(("codigo=%s\n" % cod).encode() + cuerpo)
PY

tar czf "$SALIDA" -C "$TMP" entrega
chown "$USUARIO" "$SALIDA"
rm -rf "$TMP"

echo
echo "Listo. Suban a Moodle este archivo:"
echo "   $SALIDA"
